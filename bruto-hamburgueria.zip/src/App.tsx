/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState, useMemo } from 'react';
import { 
  Instagram, 
  MessageCircle, 
  Clock, 
  MapPin, 
  ChevronRight, 
  Flame, 
  UtensilsCrossed,
  Beer,
  ShoppingBag,
  Star,
  Share2,
  ShoppingCart,
  X,
  Plus,
  Minus,
  Trash2
} from 'lucide-react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { clsx, type ClassValue } from 'clsx';
import { twMerge } from 'tailwind-merge';

gsap.registerPlugin(ScrollTrigger);

function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

// --- Types ---
interface Product {
  id: string;
  name: string;
  description: string;
  price: string;
  category: 'burgers' | 'combos' | 'sides' | 'drinks';
  image: string;
  highlight?: boolean;
}

interface CartItem extends Product {
  quantity: number;
}

// --- Data ---
const PRODUCTS: Product[] = [
  // --- Hambúrgueres ---
  {
    id: 'bruto',
    name: 'Bruto',
    description: 'Pão Brioche, blend bovino 160g, creme de cheddar, cebola caramelizada, bacon e molho bruto.',
    price: 'R$ 30,00',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=800&auto=format&fit=crop&keywords=burger-cheddar',
    highlight: true,
  },
  {
    id: 'bacon-chili',
    name: 'Bacon Chili',
    description: 'Pão brioche, blend bovino 160g, bacon, queijo muçarela, alface, tomate, geleia de pimenta e molho bruto.',
    price: 'R$ 31,90',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1553979459-d2229ba7433b?q=80&w=800&auto=format&fit=crop&keywords=bacon-burger',
  },
  {
    id: 'original-memo',
    name: 'Original Memo',
    description: 'Pão brioche, blend bovino 160g, queijo muçarela, molho bruto.',
    price: 'R$ 25,00',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?q=80&w=800&auto=format&fit=crop&keywords=classic-burger',
  },
  {
    id: 'lacado',
    name: 'Laçado',
    description: 'Pão brioche, blend bovino 160g, queijo muçarela, alface, tomate, cebola roxa e molho bruto.',
    price: 'R$ 29,00',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?q=80&w=800&auto=format&fit=crop&keywords=burger-veggies',
  },
  {
    id: 'american-blend',
    name: 'American Blend',
    description: 'Pão brioche, blend bovino 160g, queijo muçarela, alface, tomate, cebola roxa, picles e molho american.',
    price: 'R$ 31,90',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=800&auto=format&fit=crop&keywords=american-burger',
  },
  {
    id: 'brutao',
    name: 'Brutão',
    description: 'Pão brioche, 2 blends bovino 160g, queijo muçarela e cheddar, cebola caramelizada, bacon e molho bruto.',
    price: 'R$ 38,00',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1568901346375-23c9450c58cd?q=80&w=800&auto=format&fit=crop&keywords=double-burger',
    highlight: true,
  },
  {
    id: 'trajado',
    name: 'Trajado',
    description: 'Pão brioche, blend bovino 160g, queijo muçarela, anel de cebola, alface americano e molho bruto.',
    price: 'R$ 30,00',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?q=80&w=800&auto=format&fit=crop&keywords=onion-ring-burger',
  },
  {
    id: 'frango-bruto',
    name: 'Frango bruto',
    description: 'Pão brioche, hamburguer de ling. de frango e, queijo mussarela, alface, tomate e molho bruto.',
    price: 'R$ 30,00',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1626700051175-6818013e1d4f?q=80&w=800&auto=format&fit=crop&keywords=chicken-burger',
  },
  {
    id: 'bruto-memo',
    name: 'Bruto Memo',
    description: 'Pão Brioche, blend bovino 160g, creme cheddar, champignon grelhado no molho shoyu, cebola caramelizada e molho barbecue.',
    price: 'R$ 29,00',
    category: 'burgers',
    image: 'https://images.unsplash.com/photo-1594212699903-ec8a3eca50f5?q=80&w=800&auto=format&fit=crop&keywords=mushroom-burger',
    highlight: true,
  },

  // --- Combos ---
  {
    id: 'combo-bruto',
    name: 'Combo Bruto',
    description: 'Pão Brioche, blend bovino 160g, creme de cheddar, cebola caramelizada, bacon e molho bruto + Acompanhamento + Bebida.',
    price: 'R$ 46,00',
    category: 'combos',
    image: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=800&auto=format&fit=crop&keywords=burger-combo',
    highlight: true,
  },
  {
    id: 'combo-bacon-chili',
    name: 'Combo Bacon Chili',
    description: 'Pão brioche, blend bovino 160g, bacon, queijo muçarela, alface, tomate, geleia de pimenta e molho bruto + Acompanhamento + Bebida.',
    price: 'R$ 47,90',
    category: 'combos',
    image: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=800&auto=format&fit=crop&keywords=bacon-combo',
  },
  {
    id: 'combo-original-memo',
    name: 'Combo Original Memo',
    description: 'Pão Brioche, blend bovino 160g, queijo muçarela, molho bruto + Acompanhamento + Bebida.',
    price: 'R$ 41,00',
    category: 'combos',
    image: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=800&auto=format&fit=crop&keywords=classic-combo',
  },
  {
    id: 'combo-lacado',
    name: 'Combo Laçado',
    description: 'Pão brioche, blend bovino 160g, queijo muçarela, alface, tomate, cebola roxa e molho bruto + Acompanhamento + Bebida.',
    price: 'R$ 45,00',
    category: 'combos',
    image: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=800&auto=format&fit=crop&keywords=veggie-combo',
  },
  {
    id: 'combo-american-blend',
    name: 'Combo American Blend',
    description: 'Pão brioche, blend bovino 160g, queijo muçarela, alface, tomate, cebola roxa, picles e molho american + Acompanhamento + Bebida.',
    price: 'R$ 47,90',
    category: 'combos',
    image: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=800&auto=format&fit=crop&keywords=american-combo',
  },
  {
    id: 'combo-brutao',
    name: 'Combo Brutão',
    description: 'Pão brioche, 2 blends bovino 160g, queijo muçarela e cheddar, cebola caramelizada, bacon e molho bruto + Acompanhamento + Bebida.',
    price: 'R$ 54,00',
    category: 'combos',
    image: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=800&auto=format&fit=crop&keywords=double-combo',
    highlight: true,
  },
  {
    id: 'combo-trajado',
    name: 'Combo Trajado',
    description: 'Pão brioche, blend bovino 160g, queijo muçarela, anel de cebola, alface americano e molho bruto + Acompanhamento + Bebida.',
    price: 'R$ 46,00',
    category: 'combos',
    image: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=800&auto=format&fit=crop&keywords=onion-combo',
  },
  {
    id: 'combo-bruto-memo',
    name: 'Combo Bruto Memo',
    description: 'Pão Brioche, blend bovino 160g, creme cheddar, champignon grelhado no molho shoyu, cebola caramelizado e barbecue + Acompanhamento + Bebida.',
    price: 'R$ 45,00',
    category: 'combos',
    image: 'https://images.unsplash.com/photo-1534790566855-4cb788d389ec?q=80&w=800&auto=format&fit=crop&keywords=mushroom-combo',
  },

  // --- Acompanhamentos ---
  {
    id: 'batata-sure-crispy',
    name: 'Batata Sure Crispy',
    description: '200g de batatas fritas super crocantes.',
    price: 'R$ 14,00',
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?q=80&w=800&auto=format&fit=crop&keywords=crispy-fries',
  },
  {
    id: 'batata-rustica',
    name: 'Batata Rústica',
    description: '200g de batata temperada com Lemon Pepper.',
    price: 'R$ 14,00',
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?q=80&w=800&auto=format&fit=crop&keywords=rustic-fries',
  },
  {
    id: 'batata-smile',
    name: 'Batata Smile',
    description: '10 unidades de batata smile.',
    price: 'R$ 14,00',
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?q=80&w=800&auto=format&fit=crop&keywords=smile-fries',
  },
  {
    id: 'batata-cheddar-bacon',
    name: 'Batata com Cheddar e Bacon',
    description: 'Porção de 400g de batata, cheddar e bacon.',
    price: 'R$ 22,90',
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1573080496219-bb080dd4f877?q=80&w=800&auto=format&fit=crop&keywords=cheddar-bacon-fries',
    highlight: true,
  },
  {
    id: 'queijo-gouda',
    name: 'Empanado de Queijo Gouda',
    description: '8 unidades de queijo gouda empanado.',
    price: 'R$ 21,90',
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1541529086526-db283c563270?q=80&w=800&auto=format&fit=crop&keywords=cheese-bites',
  },
  {
    id: 'aneis-cebola',
    name: 'Porção de Anéis de Cebola',
    description: '8 unidades de anéis de cebola fritos.',
    price: 'R$ 21,90',
    category: 'sides',
    image: 'https://images.unsplash.com/photo-1639122181441-3f4313a2947a?q=80&w=800&auto=format&fit=crop&keywords=onion-rings',
  },

  // --- Bebidas ---
  {
    id: 'coca-lata',
    name: 'Coca Lata 310ml',
    description: 'Refrigerante Coca-Cola original lata 310ml.',
    price: 'R$ 6,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=800&auto=format&fit=crop&keywords=coca-cola-can',
  },
  {
    id: 'coca-zero',
    name: 'Coca Cola Zero',
    description: 'Refrigerante Coca-Cola sem açúcar lata 310ml.',
    price: 'R$ 6,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1543253687-c931c8e01820?q=80&w=800&auto=format&fit=crop&keywords=coca-cola-zero',
  },
  {
    id: 'fanta-lata',
    name: 'Fanta Lata 310ml',
    description: 'Refrigerante Fanta Laranja lata 310ml.',
    price: 'R$ 6,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1624517452488-04869289c4ca?q=80&w=800&auto=format&fit=crop&keywords=fanta-orange',
  },
  {
    id: 'fanta-uva',
    name: 'Fanta Uva',
    description: 'Refrigerante Fanta Uva lata 310ml.',
    price: 'R$ 6,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1527661591475-527312dd65f5?q=80&w=800&auto=format&fit=crop&keywords=grape-soda',
  },
  {
    id: 'guarana-lata',
    name: 'Guaraná Antártica Lata 269ml',
    description: 'Refrigerante Guaraná Antártica lata 269ml.',
    price: 'R$ 6,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=800&auto=format&fit=crop&keywords=guarana',
  },
  {
    id: 'guarana-zero',
    name: 'Guaraná Antártica Zero',
    description: 'Refrigerante Guaraná Antártica sem açúcar lata 269ml.',
    price: 'R$ 6,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=800&auto=format&fit=crop&keywords=guarana-zero',
  },
  {
    id: 'sprite',
    name: 'Sprite',
    description: 'Refrigerante Sprite lata 310ml.',
    price: 'R$ 6,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?q=80&w=800&auto=format&fit=crop&keywords=sprite',
  },
  {
    id: 'h2o-limao',
    name: 'H2O Limão',
    description: 'Bebida levemente gaseificada sabor limão 500ml.',
    price: 'R$ 10,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1513558161293-cdaf765ed2fd?q=80&w=800&auto=format&fit=crop&keywords=lemon-water',
  },
  {
    id: 'suco-prats-laranja',
    name: 'Suco Prats Laranja 300ml',
    description: 'Suco de laranja integral Prats 300ml.',
    price: 'R$ 10,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1600266484163-4c33a850a4ac?q=80&w=800&auto=format&fit=crop&keywords=orange-juice',
  },
  {
    id: 'suco-prats-goiaba',
    name: 'Suco Prats Goiaba 300ml',
    description: 'Suco de goiaba integral Prats 300ml.',
    price: 'R$ 10,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1528825871115-3581a5387919?q=80&w=800&auto=format&fit=crop&keywords=guava-juice',
  },
  {
    id: 'suco-prats-uva',
    name: 'Suco Prats Uva 300ml',
    description: 'Suco de uva integral Prats 300ml.',
    price: 'R$ 10,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1541324908094-89d401807b05?q=80&w=800&auto=format&fit=crop&keywords=grape-juice',
  },
  {
    id: 'suco-del-valle',
    name: 'Suco Del Valle',
    description: 'Suco Del Valle lata 290ml. Sabores diversos.',
    price: 'R$ 6,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1621506289937-a8e4df240d0b?q=80&w=800&auto=format&fit=crop&keywords=juice-can',
  },
  {
    id: 'red-bull',
    name: 'Red Bull 250 ml',
    description: 'Energético Red Bull 250ml.',
    price: 'R$ 15,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1622543925917-763c34d15384?q=80&w=800&auto=format&fit=crop&keywords=red-bull',
  },
  {
    id: 'monster',
    name: 'Monster 473ml',
    description: 'Energético Monster 473ml.',
    price: 'R$ 15,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1622543925917-763c34d15384?q=80&w=800&auto=format&fit=crop&keywords=monster-energy',
  },
  {
    id: 'agua-tonica',
    name: 'Água Tônica 350ml',
    description: 'Água Tônica lata 350ml.',
    price: 'R$ 7,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1598614187854-26a60e982dc4?q=80&w=800&auto=format&fit=crop&keywords=tonic-water',
  },
  {
    id: 'schweppes',
    name: 'Schweppes 310ml',
    description: 'Refrigerante Schweppes Citrus lata 310ml.',
    price: 'R$ 7,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1625772299848-391b6a87d7b3?q=80&w=800&auto=format&fit=crop&keywords=schweppes',
  },
  {
    id: 'agua-gas',
    name: 'Água com Gás 500ml',
    description: 'Água mineral com gás 500ml.',
    price: 'R$ 4,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1548964856-ac520a4a9910?q=80&w=800&auto=format&fit=crop&keywords=sparkling-water',
  },
  {
    id: 'agua-sem-gas',
    name: 'Água sem Gás 500ml',
    description: 'Água mineral sem gás 500ml.',
    price: 'R$ 3,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1548964856-ac520a4a9910?q=80&w=800&auto=format&fit=crop&keywords=water-bottle',
  },
  {
    id: 'funada-1-5',
    name: 'Funada 1,5 litros',
    description: 'Refrigerante Funada 1,5 litros.',
    price: 'R$ 8,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1622483767028-3f66f32aef97?q=80&w=800&auto=format&fit=crop&keywords=soda-bottle',
  },
  {
    id: 'coca-2l',
    name: 'Coca Cola 2L',
    description: 'Refrigerante Coca-Cola original 2 litros.',
    price: 'R$ 15,00',
    category: 'drinks',
    image: 'https://images.unsplash.com/photo-1554866585-cd94860890b7?q=80&w=800&auto=format&fit=crop&keywords=coca-cola-2l',
  }
];

const CATEGORIES = [
  { id: 'burgers', label: 'Hambúrgueres', icon: UtensilsCrossed },
  { id: 'combos', label: 'Combos', icon: ShoppingBag },
  { id: 'sides', label: 'Acompanhamentos', icon: Flame },
  { id: 'drinks', label: 'Bebidas', icon: Beer },
] as const;

// --- Components ---

const ProductCard = ({ product, onAddToCart }: { product: Product, onAddToCart: (p: Product) => void }) => {
  const cardRef = useRef<HTMLDivElement>(null);

  return (
    <div 
      ref={cardRef}
      className={cn(
        "group relative overflow-hidden rounded-lg bg-zinc-900/50 transition-all duration-300 hover:scale-[1.02]",
        product.highlight && "fire-gradient-border"
      )}
    >
      <div className="aspect-[4/3] overflow-hidden">
        <img 
          src={product.image} 
          alt={product.name}
          className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
          referrerPolicy="no-referrer"
        />
        {product.highlight && (
          <div className="absolute top-3 right-3 z-10 rounded-full bg-primary px-3 py-1 text-[10px] font-display text-background">
            MAIS PEDIDO
          </div>
        )}
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between gap-2">
          <h3 className="text-xl leading-tight">{product.name}</h3>
          <span className="whitespace-nowrap font-display text-primary">{product.price}</span>
        </div>
        <p className="mt-2 text-sm text-zinc-400 line-clamp-2">{product.description}</p>
        <button 
          onClick={() => onAddToCart(product)}
          className="mt-4 flex w-full items-center justify-center gap-2 rounded bg-zinc-800 py-2 text-xs font-bold uppercase tracking-widest transition-colors hover:bg-primary hover:text-background"
        >
          Adicionar <ChevronRight size={14} />
        </button>
      </div>
    </div>
  );
};

export default function App() {
  const [activeCategory, setActiveCategory] = useState<Product['category']>('burgers');
  const [isOpen, setIsOpen] = useState(false);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [customerName, setCustomerName] = useState('');
  const [customerAddress, setCustomerAddress] = useState('');
  
  const heroRef = useRef<HTMLDivElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => 
          item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item
        );
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    setIsCartOpen(true);
  };

  const removeFromCart = (productId: string) => {
    setCart(prev => prev.filter(item => item.id !== productId));
  };

  const updateQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === productId) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const cartTotal = useMemo(() => {
    return cart.reduce((acc, item) => {
      const price = parseFloat(item.price.replace('R$ ', '').replace(',', '.'));
      return acc + (price * item.quantity);
    }, 0);
  }, [cart]);

  const finalizeOrder = () => {
    if (!customerName || !customerAddress) {
      alert('Por favor, preencha seu nome e endereço.');
      return;
    }

    const itemsText = cart.map(item => 
      `• ${item.quantity}x ${item.name} (${item.price})`
    ).join('\n');

    const message = encodeURIComponent(
      `*NOVO PEDIDO - BRUTO HAMBURGUERIA*\n\n` +
      `*Cliente:* ${customerName}\n` +
      `*Endereço:* ${customerAddress}\n\n` +
      `*Itens:*\n${itemsText}\n\n` +
      `*Total:* R$ ${cartTotal.toFixed(2).replace('.', ',')}\n\n` +
      `_Enviado via Bruto Digital_`
    );

    window.open(`https://wa.me/5566999294748?text=${message}`, '_blank');
  };

  // Status logic
  useEffect(() => {
    const checkStatus = () => {
      const now = new Date();
      const day = now.getDay(); // 0: Sun, 1: Mon, ..., 2: Tue
      const hour = now.getHours();
      const minutes = now.getMinutes();
      const currentTime = hour + minutes / 60;

      // Closed on Tuesday (2)
      if (day === 2) {
        setIsOpen(false);
        return;
      }

      // Open 18:00 to 22:30
      if (currentTime >= 18 && currentTime <= 22.5) {
        setIsOpen(true);
      } else {
        setIsOpen(false);
      }
    };

    checkStatus();
    const interval = setInterval(checkStatus, 60000);
    return () => clearInterval(interval);
  }, []);

  // GSAP Animations
  useEffect(() => {
    // Text Reveal for Hero Title
    if (titleRef.current) {
      const text = titleRef.current.innerText;
      titleRef.current.innerHTML = text
        .split('')
        .map(char => `<span class="text-reveal-char">${char === ' ' ? '&nbsp;' : char}</span>`)
        .join('');

      gsap.fromTo(
        '.text-reveal-char',
        { opacity: 0, y: 20, rotateX: -90 },
        { 
          opacity: 1, 
          y: 0, 
          rotateX: 0, 
          stagger: 0.03, 
          duration: 0.8, 
          ease: "back.out(1.7)" 
        }
      );
    }

    // Hero content reveal
    gsap.from('.hero-content', {
      opacity: 0,
      y: 30,
      duration: 1,
      delay: 0.5,
      ease: "power3.out"
    });

    // Scroll reveal for menu items
    if (menuRef.current) {
      gsap.from('.menu-item', {
        scrollTrigger: {
          trigger: menuRef.current,
          start: "top 80%",
        },
        opacity: 0,
        y: 50,
        stagger: 0.1,
        duration: 0.8,
        ease: "power2.out"
      });
    }
  }, []);

  const filteredProducts = useMemo(() => 
    PRODUCTS.filter(p => p.category === activeCategory),
    [activeCategory]
  );

  const whatsappLink = "https://wa.me/5500000000000?text=Olá! Gostaria de fazer um pedido bruto.";

  const handleShare = async () => {
    const shareData = {
      title: 'Bruto Hamburgueria',
      text: 'Confira o cardápio da Bruto Hamburgueria! O hambúrguer que não aceita desculpas.',
      url: window.location.href,
    };

    try {
      if (navigator.share) {
        await navigator.share(shareData);
      } else {
        await navigator.clipboard.writeText(window.location.href);
        // Discrete feedback could be added here if needed, but for now we'll keep it simple
      }
    } catch (err) {
      console.error('Erro ao compartilhar:', err);
    }
  };

  return (
    <div className="relative min-h-screen overflow-x-hidden">
      <div className="grainy-bg" />

      {/* Header */}
      <header className="fixed top-0 z-40 w-full border-b border-zinc-800 bg-background/80 backdrop-blur-md">
        <div className="mx-auto flex max-w-7xl items-center justify-between px-4 py-4 md:px-8">
          <div className="flex flex-col">
            <img 
              src="https://ais-pre-xqkxdogm77sgiom377sjkq-612079743762.us-east1.run.app/input_file_0.png" 
              alt="Bruto Hamburgueria Logo" 
              className="h-12 w-auto md:h-16"
              referrerPolicy="no-referrer"
            />
            <div className="mt-1 flex items-center gap-2">
              <span className={cn(
                "h-2 w-2 rounded-full animate-pulse",
                isOpen ? "bg-green-500 shadow-[0_0_8px_rgba(34,197,94,0.6)]" : "bg-red-500"
              )} />
              <span className="text-[10px] font-bold uppercase tracking-tighter text-zinc-400">
                {isOpen ? "🔥 ABERTO AGORA" : "FECHADO AGORA"}
              </span>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <button 
              onClick={() => setIsCartOpen(true)}
              className="relative flex items-center justify-center rounded-full bg-zinc-800 p-2 text-primary transition-transform hover:scale-110"
            >
              <ShoppingCart size={20} />
              {cart.length > 0 && (
                <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-[10px] font-bold text-background">
                  {cart.reduce((acc, item) => acc + item.quantity, 0)}
                </span>
              )}
            </button>
            <a 
              href={whatsappLink}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 rounded-full bg-primary px-4 py-2 text-xs font-bold text-background transition-transform hover:scale-105 active:scale-95"
            >
              <MessageCircle size={16} />
              <span className="hidden sm:inline">PEDIR AGORA</span>
            </a>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section ref={heroRef} className="relative flex min-h-[80vh] flex-col items-center justify-center px-4 pt-20 text-center">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1550547660-d9450f859349?q=80&w=1920&auto=format&fit=crop&keywords=dark-burger-background" 
            alt="Hero Background"
            className="h-full w-full object-cover opacity-30 grayscale"
            referrerPolicy="no-referrer"
          />
          <div className="absolute inset-0 bg-gradient-to-b from-background via-transparent to-background" />
        </div>

        <div className="relative z-10 max-w-4xl">
          <h2 ref={titleRef} className="text-4xl leading-[0.9] md:text-7xl lg:text-8xl">
            O HAMBÚRGUER QUE NÃO ACEITA DESCULPAS.
          </h2>
          <div className="hero-content mt-6">
            <p className="mx-auto max-w-xl text-lg text-zinc-300 md:text-xl">
              Blends de 160g, pão brioche selado e o autêntico sabor artesanal. 
              Sem frescura. Só sabor bruto.
            </p>
            <div className="mt-10 flex flex-col items-center justify-center gap-4 sm:flex-row">
              <a 
                href="#menu"
                className="group flex items-center gap-3 rounded bg-primary px-8 py-4 font-display text-lg text-background transition-all hover:bg-accent hover:text-white"
              >
                VER CARDÁPIO
                <ChevronRight className="transition-transform group-hover:translate-x-1" />
              </a>
              <div className="flex items-center gap-4 text-zinc-400">
                <div className="flex -space-x-2">
                  {[1,2,3].map(i => (
                    <div key={i} className="h-8 w-8 rounded-full border-2 border-background bg-zinc-800 flex items-center justify-center">
                      <Star size={12} className="fill-primary text-primary" />
                    </div>
                  ))}
                </div>
                <span className="text-xs font-bold uppercase tracking-widest">+500 AVALIAÇÕES 5★</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Menu Section */}
      <section id="menu" ref={menuRef} className="mx-auto max-w-7xl px-4 py-20 md:px-8">
        <div className="mb-12 text-center">
          <h2 className="text-3xl md:text-5xl">CARDÁPIO EDITORIAL</h2>
          <p className="mt-2 text-primary font-bold tracking-widest uppercase text-sm">Escolha sua arma</p>
        </div>

        {/* Categories Tabs */}
        <div className="mb-12 flex flex-wrap justify-center gap-2">
          {CATEGORIES.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setActiveCategory(cat.id)}
              className={cn(
                "flex items-center gap-2 rounded-full border px-6 py-3 text-sm font-bold uppercase tracking-widest transition-all",
                activeCategory === cat.id 
                  ? "border-primary bg-primary text-background" 
                  : "border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-600"
              )}
            >
              <cat.icon size={18} />
              {cat.label}
            </button>
          ))}
        </div>

        {/* Products Grid */}
        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {filteredProducts.map((product) => (
            <div key={product.id} className="menu-item">
              <ProductCard product={product} onAddToCart={addToCart} />
            </div>
          ))}
        </div>
      </section>

      {/* Social Proof */}
      <section className="bg-zinc-900/30 py-20">
        <div className="mx-auto max-w-7xl px-4 md:px-8">
          <div className="flex flex-col items-center justify-between gap-8 md:flex-row">
            <div className="max-w-md text-center md:text-left">
              <h2 className="text-3xl">BRUTO NO INSTA</h2>
              <p className="mt-4 text-zinc-400">
                Siga a gente para ver os bastidores, promoções exclusivas e muita "food porn" de qualidade.
              </p>
              <a 
                href="https://instagram.com/brutohamburgueria"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-8 inline-flex items-center gap-3 rounded border-2 border-primary px-6 py-3 font-display text-primary transition-all hover:bg-primary hover:text-background"
              >
                <Instagram />
                @BRUTOHAMBURGUERIA
              </a>
            </div>
            
            <div className="grid grid-cols-3 gap-2 md:gap-4">
              {[
                "https://images.unsplash.com/photo-1550317138-10000687ad32?q=80&w=400&auto=format&fit=crop",
                "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?q=80&w=400&auto=format&fit=crop",
                "https://images.unsplash.com/photo-1551782450-a2132b4ba21d?q=80&w=400&auto=format&fit=crop"
              ].map((img, i) => (
                <div key={i} className="group relative aspect-square overflow-hidden rounded-lg">
                  <img 
                    src={img} 
                    alt="Instagram Post" 
                    className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-110"
                    referrerPolicy="no-referrer"
                  />
                  <div className="absolute inset-0 flex items-center justify-center bg-background/40 opacity-0 transition-opacity group-hover:opacity-100">
                    <Instagram className="text-white" />
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-zinc-800 bg-background py-12">
        <div className="mx-auto max-w-7xl px-4 md:px-8">
          <div className="grid gap-12 md:grid-cols-3">
            <div>
              <img 
                src="https://ais-pre-xqkxdogm77sgiom377sjkq-612079743762.us-east1.run.app/input_file_0.png" 
                alt="Bruto Logo" 
                className="mb-4 h-16 w-auto grayscale brightness-200"
                referrerPolicy="no-referrer"
              />
              <p className="mt-4 text-sm text-zinc-500">
                Onde o sabor encontra a força. Hambúrgueres artesanais feitos com paixão e blends selecionados.
              </p>
            </div>
            
            <div>
              <h4 className="mb-4 text-lg">HORÁRIOS</h4>
              <ul className="space-y-2 text-sm text-zinc-400">
                <li className="flex justify-between"><span>Segunda</span> <span>18:00 - 22:30</span></li>
                <li className="flex justify-center text-accent font-bold">Terça - FECHADO</li>
                <li className="flex justify-between"><span>Quarta - Domingo</span> <span>18:00 - 22:30</span></li>
              </ul>
            </div>

            <div>
              <h4 className="mb-4 text-lg">CONTATO</h4>
              <ul className="space-y-4 text-sm text-zinc-400">
                <li className="flex items-start gap-3">
                  <MapPin className="mt-1 text-primary" size={18} />
                  <span>Rua Industrial, 123 - Centro<br />São Paulo, SP</span>
                </li>
                <li className="flex items-center gap-3">
                  <Clock className="text-primary" size={18} />
                  <span>Delivery & Takeaway</span>
                </li>
              </ul>
            </div>
          </div>
          
          <div className="mt-12 border-t border-zinc-900 pt-8 flex flex-col items-center gap-4">
            <button 
              onClick={handleShare}
              className="flex items-center gap-2 text-[10px] font-bold uppercase tracking-widest text-zinc-500 transition-colors hover:text-primary"
            >
              <Share2 size={14} />
              Compartilhar Site
            </button>
            <div className="text-[10px] font-bold uppercase tracking-widest text-zinc-600">
              © 2026 BRUTO HAMBURGUERIA. TODOS OS DIREITOS RESERVADOS.
            </div>
          </div>
        </div>
      </footer>

      {/* Floating WhatsApp Button (Mobile) */}
      <a 
        href={whatsappLink}
        target="_blank"
        rel="noopener noreferrer"
        className="fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-green-500 text-white shadow-lg shadow-green-500/20 transition-transform hover:scale-110 active:scale-95 md:hidden"
      >
        <MessageCircle size={28} />
      </a>

      {/* Floating Cart Button (Mobile) */}
      {cart.length > 0 && !isCartOpen && (
        <button 
          onClick={() => setIsCartOpen(true)}
          className="fixed bottom-24 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full bg-primary text-background shadow-lg shadow-primary/20 transition-transform hover:scale-110 active:scale-95 md:hidden"
        >
          <ShoppingCart size={24} />
          <span className="absolute -top-1 -right-1 flex h-6 w-6 items-center justify-center rounded-full bg-white text-[10px] font-bold text-background">
            {cart.reduce((acc, item) => acc + item.quantity, 0)}
          </span>
        </button>
      )}

      {/* Cart Drawer / Modal */}
      {isCartOpen && (
        <div className="fixed inset-0 z-[100] flex justify-end bg-black/60 backdrop-blur-sm">
          <div className="h-full w-full max-w-md bg-zinc-950 p-6 shadow-2xl animate-in slide-in-from-right duration-300">
            <div className="flex items-center justify-between border-b border-zinc-800 pb-4">
              <div className="flex items-center gap-3">
                <ShoppingBag className="text-primary" />
                <h2 className="text-2xl font-display">SEU PEDIDO</h2>
              </div>
              <button 
                onClick={() => setIsCartOpen(false)}
                className="rounded-full bg-zinc-900 p-2 text-zinc-400 hover:text-white"
              >
                <X size={24} />
              </button>
            </div>

            <div className="mt-6 flex-1 overflow-y-auto pr-2" style={{ maxHeight: 'calc(100vh - 350px)' }}>
              {cart.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-20 text-center">
                  <ShoppingCart size={48} className="mb-4 text-zinc-800" />
                  <p className="text-zinc-500">Seu carrinho está vazio.</p>
                  <button 
                    onClick={() => setIsCartOpen(false)}
                    className="mt-4 text-sm font-bold text-primary uppercase tracking-widest"
                  >
                    Voltar ao menu
                  </button>
                </div>
              ) : (
                <div className="space-y-4">
                  {cart.map((item) => (
                    <div key={item.id} className="flex gap-4 rounded-lg bg-zinc-900/50 p-3">
                      <img 
                        src={item.image} 
                        alt={item.name} 
                        className="h-20 w-20 rounded object-cover"
                        referrerPolicy="no-referrer"
                      />
                      <div className="flex flex-1 flex-col justify-between">
                        <div>
                          <div className="flex items-start justify-between">
                            <h4 className="font-bold">{item.name}</h4>
                            <button 
                              onClick={() => removeFromCart(item.id)}
                              className="text-zinc-600 hover:text-red-500"
                            >
                              <Trash2 size={16} />
                            </button>
                          </div>
                          <p className="text-xs text-primary">{item.price}</p>
                        </div>
                        <div className="flex items-center gap-3">
                          <button 
                            onClick={() => updateQuantity(item.id, -1)}
                            className="rounded bg-zinc-800 p-1 text-zinc-400 hover:bg-zinc-700"
                          >
                            <Minus size={14} />
                          </button>
                          <span className="text-sm font-bold">{item.quantity}</span>
                          <button 
                            onClick={() => updateQuantity(item.id, 1)}
                            className="rounded bg-zinc-800 p-1 text-zinc-400 hover:bg-zinc-700"
                          >
                            <Plus size={14} />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>

            {cart.length > 0 && (
              <div className="mt-auto border-t border-zinc-800 pt-6">
                <div className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500">Seu Nome</label>
                    <input 
                      type="text" 
                      value={customerName}
                      onChange={(e) => setCustomerName(e.target.value)}
                      placeholder="Como podemos te chamar?"
                      className="mt-1 w-full rounded border border-zinc-800 bg-zinc-900 px-4 py-2 text-sm focus:border-primary focus:outline-none"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] font-bold uppercase tracking-widest text-zinc-500">Endereço de Entrega</label>
                    <textarea 
                      value={customerAddress}
                      onChange={(e) => setCustomerAddress(e.target.value)}
                      placeholder="Rua, número, bairro e referência"
                      className="mt-1 w-full rounded border border-zinc-800 bg-zinc-900 px-4 py-2 text-sm focus:border-primary focus:outline-none"
                      rows={2}
                    />
                  </div>
                </div>

                <div className="mt-6 flex items-center justify-between border-t border-zinc-800 pt-4">
                  <span className="text-lg font-display">TOTAL</span>
                  <span className="text-2xl font-display text-primary">R$ {cartTotal.toFixed(2).replace('.', ',')}</span>
                </div>

                <button 
                  onClick={finalizeOrder}
                  className="mt-6 flex w-full items-center justify-center gap-3 rounded bg-primary py-4 font-display text-lg text-background transition-all hover:bg-accent hover:text-white"
                >
                  FINALIZAR NO WHATSAPP
                  <MessageCircle size={20} />
                </button>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
