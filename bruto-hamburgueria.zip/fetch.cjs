const https = require('https');

https.get('https://delivery.yooga.app/bruto-hamburgueria/tabs/home', (res) => {
  let data = '';
  res.on('data', (chunk) => { data += chunk; });
  res.on('end', () => {
    console.log(data);
  });
}).on('error', (err) => {
  console.log('Error: ' + err.message);
});
